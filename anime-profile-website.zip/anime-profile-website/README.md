# Anime-inspired personal profile website

A responsive, anime-inspired profile page made with plain HTML, CSS, and JavaScript. It includes floating stars, purple glow effects, social links, an About Me section, a live local clock, and a basic audio player.

## Files
- `index.html` — content and page structure
- `style.css` — colors, layout, responsive design, and animations
- `script.js` — live clock and audio-player behavior
- `assets/profile.jpg` — put your own profile image here
- `assets/song.mp3` — put an audio file you have permission to use here

## Customize it
1. Open `index.html` in a code editor such as Visual Studio Code or a plain text editor.
2. Search for `Your Name` and replace it with your display name.
3. Edit the tagline, intro, About Me paragraph, and interest chips.
4. Replace the example Instagram, Discord, and GitHub URLs with your own public profile links. Remove any links you don't want.
5. Add an image named `profile.jpg` inside the `assets` folder. Keep that exact filename, or change the image path in `index.html`.
6. Add an audio file named `song.mp3` inside the `assets` folder. Use music you own or have permission to share. Browsers normally require a visitor to press Play before audio begins.
7. Open `index.html` in your browser to preview it.

## Publish with GitHub Pages (free)
1. Sign in or create an account at https://github.com/.
2. Click **New repository**. Name it `my-anime-profile` (or another name you like). For the easiest setup, set it to **Public**. Do not upload private information.
3. Open the new repository. Click **Add file → Upload files**.
4. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder with your image and song. Make sure `index.html` is in the repository's top level, not buried inside another folder.
5. Click **Commit changes**.
6. Open the repository's **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Choose branch **main** and folder **/(root)**, then click **Save**.
9. Wait a few minutes. The Pages screen will show your published site URL, usually `https://YOUR-USERNAME.github.io/my-anime-profile/`.
10. Visit the URL. If you update files later, commit the changes and GitHub Pages will publish the update.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Privacy reminder
A public GitHub Pages site can be viewed by anyone. Don't publish your home address, phone number, school, private account details, or anything else you want to keep private.
