// ✦ Personalize this website by editing the details in index.html.
const clock = document.getElementById('clock');
const dateLine = document.getElementById('date');
const year = document.getElementById('year');

function updateClock() {
  const now = new Date();
  clock.textContent = now.toLocaleTimeString([], {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  });
  dateLine.textContent = now.toLocaleDateString([], {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });
}
updateClock();
setInterval(updateClock, 1000);
year.textContent = `© ${new Date().getFullYear()} YOUR NAME`;

// Music player: place your own permitted audio file at assets/song.mp3.
const audio = document.getElementById('audio');
const playButton = document.getElementById('play-button');
const muteButton = document.getElementById('mute-button');
const playerStatus = document.getElementById('player-status');
const progress = document.getElementById('progress');
const currentTime = document.getElementById('current-time');
const duration = document.getElementById('duration');
const equalizer = document.getElementById('equalizer');

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}
playButton.addEventListener('click', async () => {
  if (audio.paused) {
    try {
      await audio.play();
      playButton.textContent = 'Ⅱ';
      playButton.setAttribute('aria-label', 'Pause music');
      playerStatus.textContent = 'Now playing';
      equalizer.classList.add('playing');
    } catch {
      playerStatus.textContent = 'Add assets/song.mp3 first';
    }
  } else {
    audio.pause();
    playButton.textContent = '▶';
    playButton.setAttribute('aria-label', 'Play music');
    playerStatus.textContent = 'Paused';
    equalizer.classList.remove('playing');
  }
});
muteButton.addEventListener('click', () => {
  audio.muted = !audio.muted;
  muteButton.textContent = audio.muted ? '×' : '♫';
  muteButton.setAttribute('aria-label', audio.muted ? 'Unmute music' : 'Mute music');
});
audio.addEventListener('loadedmetadata', () => duration.textContent = formatTime(audio.duration));
audio.addEventListener('timeupdate', () => {
  currentTime.textContent = formatTime(audio.currentTime);
  progress.style.width = audio.duration ? `${audio.currentTime / audio.duration * 100}%` : '0%';
});
audio.addEventListener('ended', () => {
  playButton.textContent = '▶';
  playButton.setAttribute('aria-label', 'Play music');
  playerStatus.textContent = 'Track finished';
  equalizer.classList.remove('playing');
});
audio.addEventListener('error', () => {
  playerStatus.textContent = 'Add assets/song.mp3 first';
});

// Fade cards in as they enter view; the CSS animation remains a fallback.
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08 });
  document.querySelectorAll('.panel-reveal').forEach(card => {
    card.style.animationPlayState = 'paused';
    observer.observe(card);
  });
}
